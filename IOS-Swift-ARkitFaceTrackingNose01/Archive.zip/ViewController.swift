//
//  ViewController.swift
//  IOS-Swift-ARkitFaceTrackingNose01
//
//  Created by Pooya on 2018-11-27.
//  Copyright © 2018 Soonin. All rights reserved.
//

import UIKit
import ARKit
import ReplayKit
import Lottie

class ViewController: UIViewController , RPScreenRecorderDelegate {
    private var animationView: LottieAnimationView?

    @IBOutlet var sceneView: ARSCNView!
    private var emotionLabel: UILabel!
    private var gestureLabel: UILabel!
    private var lastProcessedTime: TimeInterval = 0
        private let processingInterval: TimeInterval = 0.5
    private let handGestureProcessor = HandGestureProcessor()

        private var currentEmotion: Emotion = .neutral
    let noseOptions = ["nose01", "nose02", "nose03", "nose04", "nose05", "nose06", "nose07", "nose08", "nose09"]
    let features = ["nose"]
    var featureIndices = [[6]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(ProcessInfo.processInfo.processIdentifier)
        sceneView.delegate = self
        sceneView.session.run(ARWorldTrackingConfiguration())
        setupEmotionLabel()
        setupGestureLabel()
        setupCamera()
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuratio = ARFaceTrackingConfiguration()
        
        sceneView.session.run(configuratio)
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        sceneView.session.pause()
    }
    func addLottieAnimationToScene() {
        // Load Lottie animation
        animationView = .init(name: "Animation - 1734702428155") // Replace with your Lottie animation file name
        animationView?.frame = CGRect(x: 0, y: 0, width: 400, height: 400) // Set the size
        animationView?.contentMode = .scaleAspectFit
        animationView?.loopMode = .loop
        animationView?.play()
        
        // Render Lottie animation as a texture
        let lottieRenderer = UIGraphicsImageRenderer(size: animationView?.frame.size ?? .zero)
        let lottieTexture = lottieRenderer.image { _ in
            animationView?.layer.render(in: UIGraphicsGetCurrentContext()!)
        }
        
        // Create AR plane with the Lottie animation texture
        let plane = SCNPlane(width: 0.2, height: 0.2) // Adjust dimensions
        plane.firstMaterial?.diffuse.contents = lottieTexture
        plane.firstMaterial?.isDoubleSided = true
        
        let planeNode = SCNNode(geometry: plane)
        planeNode.name = "lottieNode"
        planeNode.position = SCNVector3(0, 0, -0.5) // Position in front of the camera
        
        sceneView.scene.rootNode.addChildNode(planeNode)
    }
    private func setupEmotionLabel() {
            emotionLabel = UILabel()
            emotionLabel.translatesAutoresizingMaskIntoConstraints = false
            emotionLabel.textAlignment = .center
            emotionLabel.textColor = .white
            emotionLabel.backgroundColor = UIColor.black.withAlphaComponent(0.5)
            emotionLabel.layer.cornerRadius = 10
            emotionLabel.layer.masksToBounds = true
            emotionLabel.font = .systemFont(ofSize: 20, weight: .bold)
            view.addSubview(emotionLabel)
            
            NSLayoutConstraint.activate([
                emotionLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
                emotionLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                emotionLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 120),
                emotionLabel.heightAnchor.constraint(equalToConstant: 40)
            ])
        }
    
    private func setupGestureLabel() {
            gestureLabel = UILabel()
            gestureLabel.translatesAutoresizingMaskIntoConstraints = false
            gestureLabel.textAlignment = .center
            gestureLabel.textColor = .white
            gestureLabel.backgroundColor = UIColor.black.withAlphaComponent(0.5)
            gestureLabel.layer.cornerRadius = 10
            gestureLabel.layer.masksToBounds = true
            gestureLabel.font = .systemFont(ofSize: 30)
            view.addSubview(gestureLabel)
            
            NSLayoutConstraint.activate([
                gestureLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
                gestureLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                gestureLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 60),
                gestureLabel.heightAnchor.constraint(equalToConstant: 60)
            ])
        }
    private func updateNoseForEmotion(_ emotion: Emotion) {
            guard let node = sceneView.scene.rootNode.childNode(withName: "nose", recursively: true) as? Nose3DNode else {
                return
            }
            
            // You can modify the nose appearance based on emotion
            switch emotion {
            case .happy:
                node.scale = SCNVector3(0.06, 0.06, 0.06)  // Make nose slightly bigger when happy
            case .sad:
                node.scale = SCNVector3(0.04, 0.04, 0.04)  // Make nose slightly smaller when sad
            default:
                node.scale = SCNVector3(0.05, 0.05, 0.05)  // Default size
            }
        }
    func updateNoseForEmotion(_ emotion: Emotion, anchor: ARFaceAnchor) {
        removeLottieAnimation()
        guard let node = sceneView.scene.rootNode.childNode(withName: "nose", recursively: true) as? Nose3DNode else {
            return
        }
        
        let intensity = EmotionDetector.getEmotionIntensity(from: anchor, for: emotion)
        
        switch emotion {
        case .happy, .veryHappy:
            removeLottieAnimation()
            // Make nose bounce slightly when happy
//            let scaleAction = SCNAction.sequence([
//                SCNAction.scale(to: CGFloat(1.0 + (intensity * 0.2)), duration: 0.2),
//                SCNAction.scale(to: 1.0, duration: 0.2)
//            ])
//            node.runAction(scaleAction)
            node.scale = SCNVector3(0.05, 0.05, 0.05)
        case .angry, .veryAngry:
            // Make nose red and larger when angry
//            node.geometry?.firstMaterial?.diffuse.contents = UIColor(
//                red: 1.0,
//                green: 1.0 - CGFloat(intensity),
//                blue: 1.0 - CGFloat(intensity),
//                alpha: 1.0
//            )
            node.scale = SCNVector3(0.05, 0.05, 0.05)
            
        case .surprised:
            // Make nose jump up briefly
//            let jumpAction = SCNAction.sequence([
//                SCNAction.moveBy(x: 0, y: 0.02, z: 0, duration: 0.1),
//                SCNAction.moveBy(x: 0, y: -0.02, z: 0, duration: 0.1)
//            ])
//            node.runAction(jumpAction)
            node.scale = SCNVector3(0.05, 0.05, 0.05)
            
            
        default:
            // Reset to default state
            node.geometry?.firstMaterial?.diffuse.contents = UIColor.white
            node.scale = SCNVector3(0.05, 0.05, 0.05)
            addLottieAnimationToScene()
        }
    }
    func removeLottieAnimation() {
            if let nodeToRemove = sceneView.scene.rootNode.childNode(withName: "lottieNode", recursively: true) {
                nodeToRemove.removeFromParentNode()
            }
        }
    
    @IBAction func handleTap(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: sceneView)
        let results = sceneView.hitTest(location, options: nil)
        if let result = results.first,
            let node = result.node as? Nose3DNode {
//            node.next()
        }
//        startRecording(UIButton())
//        Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(stopRecording), userInfo: nil, repeats: false)
    }
    
    @IBAction func startRecording(_ sender: UIButton) {
            let recorder = RPScreenRecorder.shared()
            recorder.isMicrophoneEnabled = true
            recorder.startRecording { error in
                if let error = error {
                    print("Recording failed: \(error.localizedDescription)")
                } else {
                    print("Recording started.")
                }
            }
        }
    @IBAction func stopRecording(_ sender: UIButton) {
            let recorder = RPScreenRecorder.shared()
            recorder.stopRecording { previewController, error in
                if let error = error {
                    print("Stopping failed: \(error.localizedDescription)")
                } else if let previewController = previewController {
                    previewController.previewControllerDelegate = self
                    self.handleRecordedVideo(previewController: previewController)
                }
            }
        }
    private func handleRecordedVideo(previewController: RPPreviewViewController) {
            guard let outputURL = previewController.value(forKey: "_movieURL") as? URL else {
                print("Failed to retrieve the recorded video URL")
                return
            }
            
            // Upload the video
//            uploadVideo(to: "https://yourserver.com/upload", fileURL: outputURL)
        }
    
    func updateFeatures(for node: SCNNode, using anchor: ARFaceAnchor) {
        print(featureIndices)
        for (feature, indices) in zip(features, featureIndices) {
            let child = node.childNode(withName: feature, recursively: false) as? Nose3DNode
            let vertices = indices.map { anchor.geometry.vertices[$0] }
            child?.updatePosition(for: vertices)
        }
    }
    
}
extension ViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    private func setupCamera() {
        // Request camera permission
        AVCaptureDevice.requestAccess(for: .video) { granted in
            if granted {
                DispatchQueue.main.async {
                    self.setupVideoCapture()
                }
            }
        }
    }
    
    private func setupVideoCapture() {
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else { return }
        
        let session = AVCaptureSession()
        session.sessionPreset = .high
        
        do {
            let input = try AVCaptureDeviceInput(device: device)
            session.addInput(input)
            
            let videoOutput = AVCaptureVideoDataOutput()
            videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
            session.addOutput(videoOutput)
            
            // Start the session on a background thread
            DispatchQueue.global(qos: .background).async {
                session.startRunning()
            }
        } catch {
            print("Camera setup error: \(error)")
        }
    }
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        let currentTime = CACurrentMediaTime()
        guard currentTime - lastProcessedTime >= processingInterval else { return }
        
        lastProcessedTime = currentTime
        
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let context = CIContext()
        guard let cgImage = context.createCGImage(ciImage, from: ciImage.extent) else { return }
        
        let gesture = handGestureProcessor.detectGesture(in: cgImage)
        
        DispatchQueue.main.async {
            self.gestureLabel.text = gesture.description
            
            // Trigger actions based on gestures
            switch gesture {
            case .victory:
                // Victory gesture detected
                self.handleVictoryGesture()
            case .middleFinger:
                // Middle finger gesture detected
                self.handleMiddleFingerGesture()
            default:
                break
            }
        }
    }
    
    private func handleVictoryGesture() {
        // Add victory-specific animations or actions
        guard let node = sceneView.scene.rootNode.childNode(withName: "nose", recursively: true) as? Nose3DNode else {
            return
        }
        
        // Create a bounce animation
        let scaleUp = SCNAction.scale(to: 1.2, duration: 0.1)
        let scaleDown = SCNAction.scale(to: 1.0, duration: 0.1)
        let bounceSequence = SCNAction.sequence([scaleUp, scaleDown])
        
        // Add a rotation for victory
        let rotation = SCNAction.rotateBy(x: 0, y: CGFloat.pi * 2, z: 0, duration: 0.5)
        
        // Combine animations
        let group = SCNAction.group([bounceSequence, rotation])
        node.runAction(group)
    }
    
    private func handleMiddleFingerGesture() {
        // Add middle finger-specific animations or actions
        guard let node = sceneView.scene.rootNode.childNode(withName: "nose", recursively: true) as? Nose3DNode else {
            return
        }
        
        // Create a shake animation
        let shakeLeft = SCNAction.moveBy(x: -0.02, y: 0, z: 0, duration: 0.05)
        let shakeRight = SCNAction.moveBy(x: 0.02, y: 0, z: 0, duration: 0.05)
        let shakeSequence = SCNAction.sequence([shakeLeft, shakeRight, shakeLeft])
        
        // Add a color change
        let redColor = SCNAction.customAction(duration: 0.1) { node, _ in
            node.geometry?.firstMaterial?.diffuse.contents = UIColor.red
        }
        let resetColor = SCNAction.customAction(duration: 0.1) { node, _ in
            node.geometry?.firstMaterial?.diffuse.contents = UIColor.white
        }
        
        // Combine animations
        let group = SCNAction.sequence([
            SCNAction.group([shakeSequence, redColor]),
            resetColor
        ])
        node.runAction(group)
    }
}
extension ViewController: ARSCNViewDelegate {
    
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        
        let device: MTLDevice!
        device = MTLCreateSystemDefaultDevice()
        guard let faceAnchor = anchor as? ARFaceAnchor else {
            return nil
        }
        let faceGeometry = ARSCNFaceGeometry(device: device)
        let node = SCNNode(geometry: faceGeometry)
                node.geometry?.firstMaterial?.fillMode = .lines
        //node.geometry?.firstMaterial?.transparency = 0.0
        
        let noseNode = Nose3DNode(with: [""])//FaceNode(with: noseOptions)
        noseNode.name = "nose"
        noseNode.position = SCNVector3(0, 0, 0) // Adjust this to position the 3D nose correctly
        noseNode.scale = SCNVector3(0.05, 0.05, 0.05)
        node.addChildNode(noseNode)
        
        updateFeatures(for: node, using: faceAnchor)
        
        return node
    }
    
    func renderer(
            _ renderer: SCNSceneRenderer,
            didUpdate node: SCNNode,
            for anchor: ARAnchor) {
            guard let faceAnchor = anchor as? ARFaceAnchor,
                let faceGeometry = node.geometry as? ARSCNFaceGeometry else {
                    return
            }
            
            // Detect emotion
            let detectedEmotion = EmotionDetector.detectEmotion(from: faceAnchor)
            if detectedEmotion != currentEmotion {
                currentEmotion = detectedEmotion
                DispatchQueue.main.async {
                    self.emotionLabel.text = detectedEmotion.description
                    self.updateNoseForEmotion(detectedEmotion, anchor: faceAnchor)
                }
            }
            
            faceGeometry.update(from: faceAnchor.geometry)
            updateFeatures(for: node, using: faceAnchor)
        }
    
    
}

extension ViewController: RPPreviewViewControllerDelegate {
    func previewControllerDidFinish(_ previewController: RPPreviewViewController) {
        previewController.dismiss(animated: true)
    }
}
enum Emotion {
    case happy
    case veryHappy
    case sad
    case verySad
    case angry
    case veryAngry
    case surprised
    case scared
    case disgusted
    case contempt
    case neutral
    case winking
    case kissing
    case tongueOut
    case sleepy
    case thinking
    
    var description: String {
        switch self {
        case .happy: return "😊 Happy"
        case .veryHappy: return "😃 Very Happy"
        case .sad: return "😢 Sad"
        case .verySad: return "😭 Very Sad"
        case .angry: return "😠 Angry"
        case .veryAngry: return "😡 Very Angry"
        case .surprised: return "😲 Surprised"
        case .scared: return "😨 Scared"
        case .disgusted: return "🤢 Disgusted"
        case .contempt: return "😏 Contempt"
        case .neutral: return "😐 Neutral"
        case .winking: return "😉 Winking"
        case .kissing: return "😘 Kissing"
        case .tongueOut: return "😛 Tongue Out"
        case .sleepy: return "😴 Sleepy"
        case .thinking: return "🤔 Thinking"
        }
    }
}

class EmotionDetector {
    static func detectEmotion(from anchor: ARFaceAnchor) -> Emotion {
        // Mouth related
        let mouthSmileLeft = anchor.blendShapes[.mouthSmileLeft]?.floatValue ?? 0.0
        let mouthSmileRight = anchor.blendShapes[.mouthSmileRight]?.floatValue ?? 0.0
        let mouthFrownLeft = anchor.blendShapes[.mouthFrownLeft]?.floatValue ?? 0.0
        let mouthFrownRight = anchor.blendShapes[.mouthFrownRight]?.floatValue ?? 0.0
        let mouthLeft = anchor.blendShapes[.mouthLeft]?.floatValue ?? 0.0
        let mouthRight = anchor.blendShapes[.mouthRight]?.floatValue ?? 0.0
        let mouthPucker = anchor.blendShapes[.mouthPucker]?.floatValue ?? 0.0
        let tongueOut = anchor.blendShapes[.tongueOut]?.floatValue ?? 0.0
        
        // Eyes related
        let eyeBlinkLeft = anchor.blendShapes[.eyeBlinkLeft]?.floatValue ?? 0.0
        let eyeBlinkRight = anchor.blendShapes[.eyeBlinkRight]?.floatValue ?? 0.0
        let eyeSquintLeft = anchor.blendShapes[.eyeSquintLeft]?.floatValue ?? 0.0
        let eyeSquintRight = anchor.blendShapes[.eyeSquintRight]?.floatValue ?? 0.0
        let eyeWideLeft = anchor.blendShapes[.eyeWideLeft]?.floatValue ?? 0.0
        let eyeWideRight = anchor.blendShapes[.eyeWideRight]?.floatValue ?? 0.0
        
        // Brow related
        let browInnerUp = anchor.blendShapes[.browInnerUp]?.floatValue ?? 0.0
        let browDownLeft = anchor.blendShapes[.browDownLeft]?.floatValue ?? 0.0
        let browDownRight = anchor.blendShapes[.browDownRight]?.floatValue ?? 0.0
        let browOuterUpLeft = anchor.blendShapes[.browOuterUpLeft]?.floatValue ?? 0.0
        let browOuterUpRight = anchor.blendShapes[.browOuterUpRight]?.floatValue ?? 0.0
        
        // Jaw and cheek
        let jawOpen = anchor.blendShapes[.jawOpen]?.floatValue ?? 0.0
        let jawLeft = anchor.blendShapes[.jawLeft]?.floatValue ?? 0.0
        let jawRight = anchor.blendShapes[.jawRight]?.floatValue ?? 0.0
        let cheekPuff = anchor.blendShapes[.cheekPuff]?.floatValue ?? 0.0
        let noseSneerLeft = anchor.blendShapes[.noseSneerLeft]?.floatValue ?? 0.0
        let noseSneerRight = anchor.blendShapes[.noseSneerRight]?.floatValue ?? 0.0
        
        // Calculated values
        let smileValue = (mouthSmileLeft + mouthSmileRight) / 2.0
        let frownValue = (mouthFrownLeft + mouthFrownRight) / 2.0
        let browDownValue = (browDownLeft + browDownRight) / 2.0
        let eyeBlinkValue = (eyeBlinkLeft + eyeBlinkRight) / 2.0
        let eyeWideValue = (eyeWideLeft + eyeWideRight) / 2.0
        let noseSneerValue = (noseSneerLeft + noseSneerRight) / 2.0
        
        // Very Angry
        if browDownValue > 0.7 && jawOpen > 0.4 && noseSneerValue > 0.5 {
            return .veryAngry
        }
        
        // Angry
        if browDownValue > 0.4 && (jawOpen > 0.3 || noseSneerValue > 0.3) {
            return .angry
        }
        
        // Very Happy
        if smileValue > 0.8 && eyeSquintLeft > 0.3 && eyeSquintRight > 0.3 {
            return .veryHappy
        }
        
        // Happy
        if smileValue > 0.5 {
            return .happy
        }
        
        // Very Sad
        if frownValue > 0.5 && browInnerUp > 0.5 {
            return .verySad
        }
        
        // Sad
        if frownValue > 0.3 || (browInnerUp > 0.3 && browDownValue > 0.3) {
            return .sad
        }
        
        // Surprised
        if eyeWideValue > 0.5 && jawOpen > 0.5 && browOuterUpLeft > 0.3 && browOuterUpRight > 0.3 {
            return .surprised
        }
        
        // Scared
        if eyeWideValue > 0.7 && browInnerUp > 0.5 && browOuterUpLeft > 0.5 && browOuterUpRight > 0.5 {
            return .scared
        }
        
        // Disgusted
        if noseSneerValue > 0.5 && mouthLeft > 0.3 && browDownValue > 0.3 {
            return .disgusted
        }
        
        // Contempt
        if mouthLeft > 0.5 || mouthRight > 0.5 {
            return .contempt
        }
        
        // Winking
        if (eyeBlinkLeft > 0.8 && eyeBlinkRight < 0.2) || (eyeBlinkRight > 0.8 && eyeBlinkLeft < 0.2) {
            return .winking
        }
        
        // Kissing
        if mouthPucker > 0.5 {
            return .kissing
        }
        
        // Tongue Out
        if tongueOut > 0.5 {
            return .tongueOut
        }
        
        // Sleepy
        if eyeBlinkValue > 0.4 && jawOpen > 0.2 {
            return .sleepy
        }
        
        // Thinking
        if browInnerUp > 0.4 && (jawLeft > 0.3 || jawRight > 0.3) {
            return .thinking
        }
        
        return .neutral
    }
    
    // Helper function to get emotion intensity (0.0 to 1.0)
    static func getEmotionIntensity(from anchor: ARFaceAnchor, for emotion: Emotion) -> Float {
        switch emotion {
        case .happy, .veryHappy:
            let smileLeft = anchor.blendShapes[.mouthSmileLeft]?.floatValue ?? 0.0
            let smileRight = anchor.blendShapes[.mouthSmileRight]?.floatValue ?? 0.0
            return (smileLeft + smileRight) / 2.0
            
        case .angry, .veryAngry:
            let browDownLeft = anchor.blendShapes[.browDownLeft]?.floatValue ?? 0.0
            let browDownRight = anchor.blendShapes[.browDownRight]?.floatValue ?? 0.0
            return (browDownLeft + browDownRight) / 2.0
            
        // Add more cases as needed
        default:
            return 0.0
        }
    }
}

// First, let's create an enum for our supported gestures
enum HandGesture {
    case thumbsUp
    case thumbsDown
    case victory
    case middleFinger
    case peace
    case fist
    case pointing
    case unknown
    
    var description: String {
        switch self {
        case .thumbsUp: return "👍"
        case .thumbsDown: return "👎"
        case .victory: return "✌️"
        case .middleFinger: return "🖕"
        case .peace: return "✌️"
        case .fist: return "✊"
        case .pointing: return "👆"
        case .unknown: return "?"
        }
    }
}

class HandGestureProcessor {
    private var handPoseRequest = VNDetectHumanHandPoseRequest()
    
    init() {
        handPoseRequest.maximumHandCount = 2 // Detect up to 2 hands
    }
    
    func detectGesture(in image: CGImage) -> HandGesture {
        let requestHandler = VNImageRequestHandler(cgImage: image, options: [:])
        
        do {
            try requestHandler.perform([handPoseRequest])
            
            guard let observations = handPoseRequest.results else {
                return .unknown
            }
            
            // Process each detected hand
            for observation in observations {
                let gesture = processHandPoseObservation(observation)
                if gesture != .unknown {
                    return gesture
                }
            }
        } catch {
            print("Hand pose detection error: \(error)")
        }
        
        return .unknown
    }
    
    private func processHandPoseObservation(_ observation: VNHumanHandPoseObservation) -> HandGesture {
        guard let thumbTip = try? observation.recognizedPoint(.thumbTip),
              let thumbIp = try? observation.recognizedPoint(.thumbIP),
              let indexTip = try? observation.recognizedPoint(.indexTip),
              let indexDip = try? observation.recognizedPoint(.indexDIP),
              let middleTip = try? observation.recognizedPoint(.middleTip),
              let middleDip = try? observation.recognizedPoint(.middleDIP),
              let ringTip = try? observation.recognizedPoint(.ringTip),
              let ringDip = try? observation.recognizedPoint(.ringDIP),
              let littleTip = try? observation.recognizedPoint(.littleTip),
              let littleDip = try? observation.recognizedPoint(.littleDIP) else {
            return .unknown
        }
        
        // Check for thumbs up
        if thumbTip.y > thumbIp.y &&
           indexTip.y < thumbTip.y &&
           middleTip.y < thumbTip.y &&
           ringTip.y < thumbTip.y &&
           littleTip.y < thumbTip.y {
            return .thumbsUp
        }
        
        // Check for thumbs down
        if thumbTip.y < thumbIp.y &&
           indexTip.y > thumbTip.y &&
           middleTip.y > thumbTip.y &&
           ringTip.y > thumbTip.y &&
           littleTip.y > thumbTip.y {
            return .thumbsDown
        }
        
        // Check for victory/peace sign
        if indexTip.y > indexDip.y &&
           middleTip.y > middleDip.y &&
           ringTip.y < ringDip.y &&
           littleTip.y < littleDip.y {
            return .victory
        }
        
        // Check for middle finger
        if middleTip.y > middleDip.y &&
           indexTip.y < indexDip.y &&
           ringTip.y < ringDip.y &&
           littleTip.y < littleDip.y {
            return .middleFinger
        }
        
        // Check for pointing
        if indexTip.y > indexDip.y &&
           middleTip.y < middleDip.y &&
           ringTip.y < ringDip.y &&
           littleTip.y < littleDip.y {
            return .pointing
        }
        
        // Check for fist
        if indexTip.y < indexDip.y &&
           middleTip.y < middleDip.y &&
           ringTip.y < ringDip.y &&
           littleTip.y < littleDip.y {
            return .fist
        }
        
        return .unknown
    }
}
